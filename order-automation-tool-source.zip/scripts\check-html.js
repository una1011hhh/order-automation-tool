const fs = require("fs");
const vm = require("vm");

function checkHtml(filePath) {
  const html = fs.readFileSync(filePath, "utf8");
  const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)];

  scripts.forEach((match) => new vm.Script(match[1]));

  const declaredIds = new Set([...html.matchAll(/\sid="([^"]+)"/g)].map((match) => match[1]));
  const referencedIds = new Set(
    scripts.flatMap((match) => [...match[1].matchAll(/getElementById\("([^"]+)"\)/g)].map((idMatch) => idMatch[1]))
  );
  const missingIds = [...referencedIds].filter((id) => !declaredIds.has(id));

  if (missingIds.length) {
    throw new Error(`${filePath} missing DOM ids: ${missingIds.join(", ")}`);
  }
}

function checkScript(filePath) {
  new vm.Script(fs.readFileSync(filePath, "utf8"));
}

checkHtml("index.html");
checkHtml("admin/orders.html");
checkScript("server.js");
checkScript("lib/orderStore.js");

console.log("Build check passed: HTML, inline scripts, DOM ids, and server scripts are valid.");
